from flask import Flask, render_template, request, redirect, session, flash
app = Flask(__name__)
app.secret_key = 'KeepItSecretKeepItSafe'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    print "Got Post Info"
    print request.form
    myName = request.form['name']
    myLocation = request.form['location']
    myLanguage = request.form['language']
    myComments = request.form['comments']
    if len(myName) < 1:
        flash("Name cannot be empty!")
    elif len(myComments) < 1:
        flash("Comment cannot be empty!")
    elif len(myComments) > 120:
        flash("Please keep comments less than 120 letters!")
    else:
        return render_template("result.html", name=myName, location=myLocation, language=myLanguage, comments=myComments)

    return redirect('/')

app.run(debug=True)
